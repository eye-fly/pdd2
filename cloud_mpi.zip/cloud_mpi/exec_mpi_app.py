#!/usr/bin/env python3
import sys
import os
import argparse
import subprocess

def exec_mpi_app(cdir, command, script):
    guser = os.environ['GCP_userID']
    IPs= []
    print("\n ### collect list of IP addresses ###")
    with open('hosts') as hostfile:
        record_ip=False
        for line in hostfile:
            clean_line=line.rstrip()
            if clean_line == "[mpi_nodes]":
                record_ip = True
            elif record_ip:
                if not clean_line:
                    break
                else:
                    print(clean_line)
                    IPs.append(clean_line)

    # copy source file to all nodes
    print("\n ### copy source code to node {} and compile ###".format(IPs[0]))

    ### Cleaning the source dir if possible
    p = subprocess.Popen(["make", "clean"], cwd=cdir)
    p.wait()

    os.system("tar zcvf {1} -C {0} .".format(cdir, "buffer/dir.tar.gz"))

    print("copy to node")

    os.system("scp -i {0} {1} {2}@{3}:./".format("buffer/id_rsa", "buffer/dir.tar.gz", guser, IPs[0]))

    os.system("ssh -i {0} {1}@{2} \"tar zxvf {3}\"".format("buffer/id_rsa", guser, IPs[0], "dir.tar.gz"))


    # Compile on first node
    os.system("ssh -i {0} {1}@{2} \"make clean; make\"".format("buffer/id_rsa", guser, IPs[0]))


    # time for executing
    if script is not None:
        print("\n ### copy exec script {} to node {} ###".format(script, IPs[0]))
        os.system("scp -i {0} {1} {2}@{3}:./".format("buffer/id_rsa", script, guser, IPs[0]))

        print("\n ### Execution of the provided script ###")

        os.system("ssh -i {0} {1}@{2} \"bash ./{3}\"".format("buffer/id_rsa", guser, IPs[0], os.path.basename(script)))
    else:

        # Exec the mpi program
        print("\n ### Execution of the provided command: {0} ###".format(command))

        os.system("ssh -i {0} {1}@{2} \"{3}\"".format("buffer/id_rsa", guser, IPs[0], command))

        # os.system("ssh -i {0} {1}@{2} \"{3} --hostfile hostfile_mpi --mca btl_base_warn_component_unused 0 ./{4}\"".format("buffer/id_rsa", guser, IPs[0], nb_ps, execfile))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--dir', dest='cdir', help='source directory. It is assumed that it includes a Makefile to compile the sources.', type=str)
    parser.add_argument('-c', '--command', dest='command', help='the command to execute, knowing that a file named hostfile_mpi contains the list of hosts', type=str)
    parser.add_argument('-s', '--script', dest='script', help='to provide a script to execute', type=str)
    options = parser.parse_args()

    if options.cdir is None or (options.command is None and options.script is None):
        parser.print_usage()
        sys.exit()

    if options.cdir is not None and not os.path.isdir(options.cdir):
        print("Source directory does not exist")
        parser.print_usage()
        sys.exit()

    if options.cdir is not None and options.command is None and options.script is None:
        print("setting option --exec or --script is required")
        parser.print_usage()
        sys.exit()

    if options.script is not None and not os.path.isfile(options.script):
        print('{} does not exist'.format(options.script))
        parser.print_usage()
        sys.exit()
    exec_mpi_app(options.cdir, options.command, options.script)
