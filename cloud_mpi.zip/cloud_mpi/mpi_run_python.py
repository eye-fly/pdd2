#!/usr/bin/env python3
import os
import argparse

def mpi_run_python(script, command):
    guser = os.environ['GCP_userID']
    IPs= []
    print("\n ### collect list of IP addresses ###")
    with open('hosts') as hostfile:
        record_ip=False
        for line in hostfile:
            clean_line=line.rstrip()
            if clean_line == "[mpi_nodes]":
                record_ip = True
            elif record_ip:
                if not clean_line:
                    break
                else:
                    print(clean_line)
                    IPs.append(clean_line)

    # copy source file to all nodes
    print("\n ### copy source code to node {} ###".format(IPs[0]))
    os.system("scp -i {0} {1} {2}@{3}:./".format("buffer/id_rsa", script, guser, IPs[0]))

    # Exec the mpi program
    print("\n ### Execution of the provided command: {0} ###".format(command))
    os.system("ssh -i {0} {1}@{2} \"{3}\"".format("buffer/id_rsa", guser, IPs[0], command))
    # os.system("ssh -i {0} {1}@{2} \"{3} --hostfile hostfile_mpi --mca btl_base_warn_component_unused 0 ./{4}\"".format("buffer/id_rsa", guser, IPs[0], nb_ps, execfile))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('script', help='Path to the Python script to execute', type=str)
    parser.add_argument('command', help='The command to execute, knowing that a file named hostfile_mpi contains the list of hosts', type=str)
    options = parser.parse_args()
    mpi_run_python(options.script, options.command)
