#!/bin/bash

export PROJECT_ID="lsml-2023"
export SERVICE_NAME="lsml-mpi"
export GCP_userID=$gcp_login
export GCP_privateKeyFile=../.ssh/id_ed25519

### Terrform setup variables
# Name of your GCP project
export TF_VAR_project=$PROJECT_ID
# Name of your selected GCP region
export TF_VAR_region=europe-central2
# Name of your selected GCP zone
export TF_VAR_zone=europe-central2-a

### Other variables used by Terrform
# Number of VMs created
export TF_VAR_machineCount=3
# VM type
export TF_VAR_machineType=e2-medium
# Prefix for you VM instances
export TF_VAR_instanceName=tf-instance
# Prefix of your GCP deployment key
export TF_VAR_deployKeyName=$SERVICE_NAME".json"

