#!/usr/bin/env sh
./parse-tf-state.py
ansible-playbook -i ./hosts install_mpi.yml
ansible-playbook -i ./hosts config_ssh.yml
ansible-playbook -i ./hosts nfs.yml
